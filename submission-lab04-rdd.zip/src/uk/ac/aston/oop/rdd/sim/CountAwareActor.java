package uk.ac.aston.oop.rdd.sim;

public interface CountAwareActor {

	public void setActorCount(Class actorClass, int count);
	
}
